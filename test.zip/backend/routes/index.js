import { Router } from 'express';

export function buildApiRouter(db) {
  const router = Router();

  router.get('/health', (req, res) => {
    res.json({ status: 'ok', entities: Object.keys(db || {}) });
  });

router.get('/navigation', (req, res) => res.json(db['navigation'] || []));
router.post('/navigation', (req, res) => {
  const items = db['navigation'] || [];
  const payload = req.body || {};
  const id = items.length ? Math.max(...items.map((item) => item.id || 0)) + 1 : 1;
  const next = { id, ...payload };
  db['navigation'] = [...items, next];
  res.status(201).json(next);
});
router.get('/page', (req, res) => res.json(db['page'] || []));
router.post('/page', (req, res) => {
  const items = db['page'] || [];
  const payload = req.body || {};
  const id = items.length ? Math.max(...items.map((item) => item.id || 0)) + 1 : 1;
  const next = { id, ...payload };
  db['page'] = [...items, next];
  res.status(201).json(next);
});
router.get('/aboutpage', (req, res) => res.json(db['aboutpage'] || []));
router.post('/aboutpage', (req, res) => {
  const items = db['aboutpage'] || [];
  const payload = req.body || {};
  const id = items.length ? Math.max(...items.map((item) => item.id || 0)) + 1 : 1;
  const next = { id, ...payload };
  db['aboutpage'] = [...items, next];
  res.status(201).json(next);
});
router.get('/contactpage', (req, res) => res.json(db['contactpage'] || []));
router.post('/contactpage', (req, res) => {
  const items = db['contactpage'] || [];
  const payload = req.body || {};
  const id = items.length ? Math.max(...items.map((item) => item.id || 0)) + 1 : 1;
  const next = { id, ...payload };
  db['contactpage'] = [...items, next];
  res.status(201).json(next);
});

  return router;
}
