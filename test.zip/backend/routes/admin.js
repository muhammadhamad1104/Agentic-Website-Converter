import { Router } from 'express';

export function buildAdminRouter() {
  const router = Router();
  router.get('/resources', (req, res) => {
    res.json({ resources: [
  "navigation",
  "page",
  "aboutpage",
  "contactpage"
] });
  });
  return router;
}
