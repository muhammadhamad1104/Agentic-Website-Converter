import cors from 'cors';
import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

import { buildApiRouter } from './routes/index.js';
import { buildAdminRouter } from './routes/admin.js';

const app = express();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const seedPath = path.join(__dirname, 'seed-data.json');

const db = JSON.parse(fs.readFileSync(seedPath, 'utf-8'));

app.use(cors());
app.use(express.json());

app.use('/api', buildApiRouter(db));
app.use('/api/admin', buildAdminRouter());

const port = Number(process.env.PORT || 3001);
app.listen(port, () => {
  console.log(`Backend running on http://localhost:${port}`);
});
