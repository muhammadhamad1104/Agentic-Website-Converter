# Generated Dynamic Website

This package is generated from your approved schema and template structure.

## Backend
- cd backend
- npm install
- npm run dev

## Frontend
- cd frontend
- npm install
- npm run dev

Frontend: http://localhost:3000
Backend: http://localhost:3001
