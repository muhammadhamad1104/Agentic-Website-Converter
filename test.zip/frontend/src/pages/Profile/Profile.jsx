import { motion } from 'framer-motion';
import './Profile.css';

export default function Profile() {
  return (
    <motion.section initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.45 }} className="simple-page">
      <h2>Profile</h2>
      <p>Profile and user preference UI can be extended here.</p>
    </motion.section>
  );
}
