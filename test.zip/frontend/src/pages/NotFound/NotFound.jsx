import { Link } from 'react-router-dom';
import './NotFound.css';

export default function NotFound() {
  return (
    <section className="not-found">
      <h2>404</h2>
      <p>The page was not found.</p>
      <Link to="/">Go Home</Link>
    </section>
  );
}
