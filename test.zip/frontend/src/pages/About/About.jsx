import { motion } from 'framer-motion';
import './About.css';

export default function About() {
  return (
    <motion.section initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.45 }} className="simple-page">
      <h2>About</h2>
      <p>This page is generated with reusable motion-based sections.</p>
    </motion.section>
  );
}
