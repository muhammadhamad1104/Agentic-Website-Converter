import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';

import { api } from '../../api/api';
import './AdminDashboard.css';

export default function AdminDashboard() {
  const [resources, setResources] = useState([]);

  useEffect(() => {
    api.get('/admin/resources').then((res) => setResources(res.data.resources || [])).catch(() => setResources([]));
  }, []);

  return (
    <motion.section className="admin-page" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.4 }}>
      <h2>Admin Panel</h2>
      <p>Generated resources registered by the conversion engine.</p>
      <ul>
        {resources.map((resource) => (
          <li key={resource}>{resource}</li>
        ))}
      </ul>
    </motion.section>
  );
}
