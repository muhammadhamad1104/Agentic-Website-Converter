import { motion } from 'framer-motion';
import './Home.css';

const entities = ["navigation", "page", "aboutpage", "contactpage"];

export default function Home() {
  return (
    <section className="home-page">
      <motion.div className="hero" initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
        <p className="eyebrow">Production UI Scaffold</p>
        <h2>Animated React Frontend + Admin + API</h2>
        <p>This website is generated from your approved schema and template structure.</p>
      </motion.div>
      <motion.div className="entity-grid" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.25, duration: 0.6, staggerChildren: 0.08 }}>
        {entities.map((entity) => (
          <motion.article className="entity-card" key={entity} whileHover={{ y: -6, scale: 1.01 }} transition={{ type: 'spring', stiffness: 260, damping: 18 }}>
            <h3>{entity}</h3>
            <p>Dynamic API endpoint available at <code>/api/{entity}</code>.</p>
          </motion.article>
        ))}
      </motion.div>
    </section>
  );
}
