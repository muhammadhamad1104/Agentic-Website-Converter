import { motion } from 'framer-motion';
import './Contact.css';

export default function Contact() {
  return (
    <motion.section initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.45 }} className="simple-page">
      <h2>Contact</h2>
      <p>Connect this page to your backend messaging endpoint.</p>
    </motion.section>
  );
}
