import './Loader.css';

export default function Loader() {
  return <div className="loader" aria-label="loading" />;
}
