import { motion } from 'framer-motion';
import { NavLink } from 'react-router-dom';
import './Header.css';

const links = [
  { to: '/', label: 'Home' },
  { to: '/about', label: 'About' },
  { to: '/contact', label: 'Contact' },
  { to: '/profile', label: 'Profile' },
  { to: '/admin', label: 'Admin' },
];

export default function Header() {
  return (
    <motion.header className="site-header" initial={{ y: -40, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ duration: 0.45 }}>
      <div className="shell header-inner">
        <h1 className="brand">Dynamic Studio</h1>
        <nav className="site-nav">
          {links.map((link) => (
            <NavLink key={link.to} to={link.to} className={({ isActive }) => (isActive ? 'active' : '')}>
              {link.label}
            </NavLink>
          ))}
        </nav>
      </div>
    </motion.header>
  );
}
